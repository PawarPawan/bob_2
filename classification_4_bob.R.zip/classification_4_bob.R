##################################################
# /user/hive/warehouse/client_db_1.db/bob_11_1_old
abt_name <- "bob_11_1_old"
score_name <- "bob_11_1_score_old_new"
h2o_server <- "91.74.169.254"
abt_path <- "hdfs://91-74-169-254:9000/user/hive/warehouse/client_db_1.db/"

# abt_name <- "BOB_11_2015-06-30.csv"
# score_name <- "BOB_11_SCORE_2015_12_31.csv"
# abt_path <- file.path("/Users/gunjan/Desktop/_delete/");
# h2o_server_local <- "localhost"
# output_path  <- file.path("/root/procva/assets/r_data/")
output_path <- file.path("/Users/gunjan/Projects/procva/assets/r_data/");

# bob_11_file <- file.path("/Users/gunjan/Desktop/_delete/bob_11.csv")
# bob_11_score_file <- file.path("/Users/gunjan/Desktop/_delete/bob_11_score.csv")

######### Do not touch anything below this line #########

library(h2o)

abt_file <- paste(abt_path, abt_name, sep = "")
score_file <- paste(abt_path, score_name, sep = "")
# score_file <-paste(abt_file, "_SCORE", sep = "") 
glm_auc_dat_file <- paste(output_path, abt_name, "_GLM_AUC_DAT.csv", sep = "")
glm_auc_file <- paste(output_path, abt_name, "_GLM_AUC.csv", sep = "")
glm_gin_file <- paste(output_path, abt_name, "_GLM_GIN.csv", sep = "")
glm_cfm_file <- paste(output_path, abt_name, "_GLM_CFM.csv", sep = "")

gbm_auc_dat_file <- paste(output_path, abt_name, "_GBM_AUC_DAT.csv", sep = "")
gbm_auc_file <- paste(output_path, abt_name, "_GBM_AUC.csv", sep = "")
gbm_gin_file <- paste(output_path, abt_name, "_GBM_GIN.csv", sep = "")
gbm_cfm_file <- paste(output_path, abt_name, "_GBM_CFM.csv", sep = "")

selected_model_file <- paste(output_path, abt_name, "_SEL_MODEL.csv", sep = "")
var_imp_file <- paste(output_path, abt_name, "_VAR_IMP.csv", sep = "")
score_output_file <- paste(output_path, abt_name, "_SCORE_OUTPUT.csv", sep = "")

print(paste("abt_file: ", abt_file));
print(paste("output_path: ", output_path));

# localH2O = h2o.init(ip = "localhost", port = 54321, startH2O = TRUE)
# dtv.hex = h2o.uploadFile(localH2O, path = abt_file , destination_frame = "dtv")
localH2O = h2o.init(ip = h2o_server, port = 54321)
BOB = h2o.importFolder(localH2O, path = abt_file, destination_frame = "bob_gk.hex")

# localH2O = h2o.init(ip = h2o_server_local, port = 54321)
# BOB = h2o.uploadFile(localH2O, path = abt_file, destination_frame = "bob_gk.hex")

ds <- BOB[BOB$C5>0,]
# ds <- BOB[BOB$a_sum_tda_txc_1_12m>0,]
ds_1 <- h2o.assign(ds,key = 'ds.hex')
# colnames(ds)
nrow(ds_1)
# Remove customer_id from the list
# drops <- c("C11")

# Bharat's changes for ignoring Nulls in target
# ds <- h2o.assign(BOB,key = 'ds.hex')
# ds_1 <- ds[ds$C160 !="NA",]

#summary(ds_1$C160)
# ds_1$Target1 <- ifelse(ds_1[,160] < 0.3, 1, 0)

# temp <- h2o.table(ds_1[,ncol(ds_1)])
# temp
# drops <- c("C11","C160")
# ds_1 <- ds_1[,!(names(ds_1) %in% drops)]

# temp <- h2o.table(ds_1[,last_col])

last_col <- ncol(ds_1)
other_cols <- 2:(last_col-1)
ds_1[,last_col] <- as.factor(ds_1[,last_col])
ds_SPLIT <- h2o.splitFrame(data=ds_1, ratios = 0.75)
TRAIN <- ds_SPLIT[[1]]
TEST <- ds_SPLIT[[2]]

# TEST <- h2o.getFrame("frame_0.40");
# nrow(TEST)
# TRAIN <- h2o.getFrame("frame_0.60");
# nrow(TRAIN)
# 
# drops <- c("C150")
# TEST = T1[,!(names(T1) %in% drops)]
# TRAIN = T1[,!(names(T2) %in% drops)]
# 
# last_col <- ncol(TRAIN)
# other_cols <- 2:(last_col-1)

# temp <- h2o.table(TRAIN[,ncol(TRAIN)])
# temp
# temp <- h2o.table(TEST[,ncol(TEST)])
# temp

drops <- c("C54","C155")
TEST_GLM = TEST[,!(names(TEST) %in% drops)]
TRAIN_GLM = TRAIN[,!(names(TRAIN) %in% drops)]
colnames(TEST_GLM)
last_col_glm <- ncol(TRAIN_GLM)
other_cols_glm <- 2:(last_col-1)


GLM_ds <- h2o.glm(y = last_col, x = other_cols, 
                training_frame = TRAIN_GLM,
                validation_frame = TEST_GLM,
                family = "binomial",
                lambda = 0)

mod_perform_GLM <- h2o.performance(GLM_ds, data = TEST_GLM)

GLM_AUC <- h2o.auc(mod_perform_GLM)
GLM_AUC
GLM_CFM <- h2o.confusionMatrix(mod_perform_GLM)
GLM_GIN <- h2o.giniCoef(mod_perform_GLM)

GLM_VARIMP <- h2o.varimp(GLM_ds)
GLM_ds_pred <- h2o.predict(GLM_ds, newdata=TEST_GLM)
ds_Pred <- h2o.assign(GLM_ds_pred[, 3L],
                      key = "ds_Pred")
Pred_results <- h2o.cbind(TEST_GLM, GLM_ds_pred)

#GLM_LIF <- h2o.gainsLift(mod_perform_GLM)
#LIFT_GLM <- as.data.frame(GLM_LIF)
plot(mod_perform_GLM, type = "roc", col = "blue", typ = "b")

GLM_AUC_DAT <- as.data.frame(GLM_ds@model$training_metrics@metrics$thresholds_and_metric_scores)


#write.table(LIFT_GLM, file = "LIFT_GLM.csv",row.names=TRUE, na="",
#col.names=TRUE, sep=",")

########### AUC PLOT ########################
fpr_GLM = GLM_ds@model$training_metrics@metrics$thresholds_and_metric_scores$fpr
tpr_GLM = GLM_ds@model$training_metrics@metrics$thresholds_and_metric_scores$tpr
fpr_val_GLM = GLM_ds@model$validation_metrics@metrics$thresholds_and_metric_scores$fpr
tpr_val_GLM = GLM_ds@model$validation_metrics@metrics$thresholds_and_metric_scores$tpr
plot(fpr_GLM,tpr_GLM, type='l')
title('AUC')
lines(fpr_val_GLM,tpr_val_GLM,type='l',col='red')
legend("bottomright",c("Train", "Validation"),col=c("black","red"),lty=c(1,1),lwd=c(3,3)) 




#### GBM Model ####
TRAIN[,last_col] <- as.factor(TRAIN[,last_col])

# GBM_ds<- h2o.gbm(y = last_col, x = other_cols, balance_classes = TRUE,
#                  training_frame = TRAIN,
#                  ntrees = 10, max_depth = 5, validation_frame = TEST,
#                  min_rows = 2)


# GBM_ds<- h2o.gbm(y = last_col, x = other_cols, balance_classes = FALSE,
#                training_frame = TRAIN,nbins = 5,
#                distribution = "bernoulli", 
#                ntrees = 10, max_depth = 5, validation_frame = TEST,
#                min_rows = 10)

#predictions = predict(model=GBM_ds,TRAIN)

# GBM_ds<- h2o.gbm(y = last_col, x = other_cols, balance_classes = TRUE,
#                  training_frame = TRAIN, nbins = 5,
#                  distribution = "bernoulli", 
#                  ntrees = 5, max_depth = 5, validation_frame = TEST,
#                  max_after_balance_size = 0.1,
#                  min_rows = 10)
# Confusion Matrix for max f1 @ threshold = 0.0385310925777308:
# 0    1    Error         Rate
# 0      15833 5782 0.267499  =5782/21615
# 1       1024 1984 0.340426   =1024/3008
# Totals 16857 7766 0.276408  =6806/24623

GBM_ds<- h2o.gbm(y = last_col, x = other_cols, balance_classes = TRUE,
                 training_frame = TRAIN, nbins = 5,
                 distribution = "bernoulli", 
                 ntrees = 5, max_depth = 5, validation_frame = TEST,
                 max_after_balance_size = 0.1,
                 min_rows = 5)

mod_perform_GBM <-h2o.performance(model=GBM_ds,data = TEST)

GBM_CFM <- h2o.confusionMatrix(mod_perform_GBM)
print(GBM_CFM)
GBM_GIN <- h2o.giniCoef(mod_perform_GBM)
GBM_GIN
#GBM_LIF <- h2o.gainsLift(mod_perform_GBM)
VarImp_GBM <- h2o.varimp(GBM_ds)
# VarImp_GBM
# write.table(VarImp_GBM, file = "VARIMP_GBM.csv",row.names=TRUE, na="", col.names=TRUE, sep=",")
GBM_AUC_DAT <- as.data.frame(GBM_ds@model$training_metrics@metrics$thresholds_and_metric_scores)

GBM_AUC <- h2o.auc(mod_perform_GBM)

plot(GBM_ds,type = "roc", col = "blue", typ = "b")
#LIFT_GBM <- as.data.frame(GBM_LIF)

#write.table(LIFT_GBM, file = "LIFT_GBM.csv",row.names=TRUE, na="",
#col.names=TRUE, sep=",")

#h2o.download_pojo(GBM_ds)

#h2o.saveModel(GBM_BOB, "C://softtag//bestModel.csv", force=TRUE)
#plot(GBM_BOB, timestep = "number_of_trees", metric = "cl")

#Model Compare

AUC <- cbind(GBM_AUC,GLM_AUC)
CFM <- cbind(GBM_CFM,GLM_CFM)
GIN <- cbind(GBM_GIN,GLM_GIN)

if (GBM_AUC > GLM_AUC) {
SelModel <- "GBM" 
Modelid <- GBM_ds@model_id

}else {SelModel <- "GLM"}

if (SelModel == "GLM") {

varImp <- GLM_VARIMP 
Modelid <- GLM_ds@model_id
}else {
varImp <- VarImp_GBM
}

mod <- as.data.frame(Modelid)
selmodid <- as.h2o(mod,localH2O,destination_frame = "modid")


# Import scoring data
print(paste("score_file: ", score_file));
SCORING = h2o.importFolder(localH2O, path = score_file, destination_frame = "bob_scoring.hex")
# SCORING = h2o.uploadFile(localH2O, path = score_file, destination_frame = "bob_scoring.hex")
nrow(SCORING)
# # Filter all accounts with A_SUM_TDA_TXC_1_12M > 0
# ds_score <- SCORING[SCORING$C146>0,]
# ds_score <- SCORING[SCORING$C5>0,]
# ds_score <- SCORING[SCORING$C5<=0,]
ds_score <- SCORING[is.na(SCORING$C5),]

# ds_score <- SCORING[is.na(SCORING$a_sum_tda_txc_1_12m),]
nrow(ds_score)
# drops <- c("C160")
# ds_1_score = ds_score[,!(names(ds_score) %in% drops)]

ds_1_score <- h2o.assign(ds_score,key = 'ds_score.hex')
nrow(ds_1_score)
# colnames(ds_1_score)

Score <- h2o.predict(GBM_ds, ds_1_score)

Score1 <- Score [, 3]

Score_results <- h2o.cbind(ds_1_score, Score1)
colnames(Score_results)
# keeps <- c("C1","p1")
keeps <- c("C1", "p1")
FINAL <- Score_results[,(names(Score_results) %in% keeps)]
nrow(FINAL)
colnames(FINAL)
# FINAL_SORTED  <- FINAL[order(-FINAL$p1),]
FINAL_HEX <- h2o.assign(FINAL,key = 'score_final_data.hex')
FINAL_DATA <- as.data.frame(FINAL_HEX)
nrow(FINAL_DATA)
FINAL_DATA_SORTED <- FINAL_DATA[order(-FINAL_DATA$p1),]

# FINAL_ORDERED=FINAL_DATA[order(FINAL_DATA[,2])]
# dd[ order(-dd[,4], dd[,1]), ]

# Start generating the files

write.table(GLM_AUC_DAT, file = glm_auc_dat_file,row.names=TRUE, na="", col.names=TRUE, sep=",")
write.table(GLM_AUC, file = glm_auc_file,row.names=TRUE, na="", col.names=TRUE, sep=",")
write.table(GLM_GIN, file = glm_gin_file,row.names=TRUE, na="", col.names=TRUE, sep=",")
write.table(GLM_CFM, file = glm_cfm_file,row.names=TRUE, na="", col.names=TRUE, sep=",")

write.table(GBM_AUC_DAT, file = gbm_auc_dat_file,row.names=TRUE, na="", col.names=TRUE, sep=",")
write.table(GBM_AUC, file = gbm_auc_file,row.names=TRUE, na="", col.names=TRUE, sep=",")
write.table(GBM_GIN, file = gbm_gin_file,row.names=TRUE, na="", col.names=TRUE, sep=",")
write.table(GBM_CFM, file = gbm_cfm_file,row.names=TRUE, na="", col.names=TRUE, sep=",")

write.table(SelModel, file = selected_model_file,row.names=TRUE, na="", col.names=TRUE, sep=",")
write.table(varImp, file = var_imp_file,row.names=TRUE, na="", col.names=TRUE, sep=",")

write.table(FINAL_DATA_SORTED, file = score_output_file, row.names=TRUE, na="", col.names=TRUE, sep=",")


# PICk the following for reports
# GLM_AUC.csv (Plot FPR vs FNR) and GBM_AUC.csv (Plot FPR vs FNR), 
# AUC
# GIN
# SelModel
# varIMp (VarImp_GBM or GLM_VARIMP based on selected Model)
# Plot LIFT_GBM and LIFT_GLM (Plot capture Rate against group)

########### AUC PLOT ########################

fpr = GBM_ds@model$training_metrics@metrics$thresholds_and_metric_scores$fpr
tpr = GBM_ds@model$training_metrics@metrics$thresholds_and_metric_scores$tpr
fpr_val = GBM_ds@model$validation_metrics@metrics$thresholds_and_metric_scores$fpr
tpr_val = GBM_ds@model$validation_metrics@metrics$thresholds_and_metric_scores$tpr
plot(fpr_val,tpr_val, type='l',col='Blue')

lines(fpr_val_GLM,tpr_val_GLM,type='l', col='Red')
legend("bottomright",c("GBM", "GLM"),col=c("Blue","red"),lty=c(1,1),lwd=c(3,3)) 
title('AUC')
text(0.8, 0.6, paste("GLM =", round(GLM_AUC, 1), "\nGBM =",
                   round(GBM_AUC, 1)))
abline(a = 0, b = 1)

####### Hard Coded for BOB now uses Base R ##########
library(lift)
train_score <- h2o.predict(GBM_ds, TEST)

train_score1 <- train_score [, 3]

train_score_results <- h2o.cbind(TEST, train_score1)
keeps <- c("C1","Target1", "p1")
FINAL_SCORE <- train_score_results[,(names(train_score_results) %in% keeps)]
FINAL_SCORE_DATA <- as.data.frame(FINAL_SCORE)
FINAL_SCORE_DATA_SORTED <- FINAL_SCORE_DATA[order(-FINAL_SCORE_DATA$p1),]

plotLift(FINAL_SCORE_DATA_SORTED$p1, FINAL_SCORE_DATA_SORTED$C1 )
TopDecileLift(FINAL_SCORE_DATA_SORTED$p1, FINAL_SCORE_DATA_SORTED$C1)
